package com.example.appmonkeykeeping.adapter

import android.content.Context
import com.example.appmonkeykeeping.model.ChartItemCategorize
import com.example.appmonkeykeeping.adapter.ItemChartAdapter.ChartHolder
import com.example.appmonkeykeeping.remote.OutcomeClickListener
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.example.appmonkeykeeping.R
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class ItemChartAdapter(private val context: Context, private val chartItemCategorizes: ArrayList<ChartItemCategorize>) : RecyclerView.Adapter<ChartHolder>() {
    private var listener: OutcomeClickListener? = null
    fun setListener(listener: OutcomeClickListener?) {
        this.listener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChartHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_category_dashboard, parent, false)
        return ChartHolder(view)
    }

    override fun onBindViewHolder(holder: ChartHolder, position: Int) {
        holder.tvName.text = chartItemCategorizes[position].name
        holder.tvMaintain.text = chartItemCategorizes[position].numberMaintain.toString()
        holder.tvOutcome.text = chartItemCategorizes[position].numberOutcome.toString()
        holder.cardColor.setCardBackgroundColor(chartItemCategorizes[position].color)
        holder.itemView.setOnClickListener {
            if (listener != null) {
            }
        }
    }

    override fun getItemCount(): Int {
        return chartItemCategorizes.size
    }

    inner class ChartHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView
        private val cardColor: CardView
        private val tvMaintain: TextView
        private val tvOutcome: TextView

        init {
            tvName = itemView.findViewById(R.id.tv_tag_chart)
            tvMaintain = itemView.findViewById(R.id.tv_maintain_item_chart)
            tvOutcome = itemView.findViewById(R.id.tv_outcome_item_chart)
            cardColor = itemView.findViewById(R.id.card_chart)
        }
    }
}