package com.example.appmonkeykeeping.remote;

import android.graphics.drawable.BitmapDrawable;

public interface ImageSet {
    void imageAfterCheck(BitmapDrawable drawable);
}
