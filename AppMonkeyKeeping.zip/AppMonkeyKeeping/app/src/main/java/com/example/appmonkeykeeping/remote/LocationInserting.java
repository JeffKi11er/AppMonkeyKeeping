package com.example.appmonkeykeeping.remote;

public interface LocationInserting {
    void enterLocation(String locationSuggested);
}
