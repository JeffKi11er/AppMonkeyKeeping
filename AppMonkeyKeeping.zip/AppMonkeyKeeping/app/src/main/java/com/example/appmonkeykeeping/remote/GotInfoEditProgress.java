package com.example.appmonkeykeeping.remote;

import com.example.appmonkeykeeping.model.Money;

public interface GotInfoEditProgress {
    void updateFinish();
}
