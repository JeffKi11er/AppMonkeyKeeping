package com.example.appmonkeykeeping.remote;

public interface OutcomeClickListener {
    void onClick(int position);
    void onLongClick(int position);
}
