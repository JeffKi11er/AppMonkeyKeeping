package com.example.appmonkeykeeping.remote;

public interface DataSaveInterface {
    void dataInSaving(String message,int unit);
}
