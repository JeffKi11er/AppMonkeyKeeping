package com.example.appmonkeykeeping.remote;

public interface ItemClickListener {
    void onClick(int position);
    void onLongClick(int position);
}
